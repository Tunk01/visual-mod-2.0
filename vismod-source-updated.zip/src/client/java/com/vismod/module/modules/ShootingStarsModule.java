package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import com.vismod.render.CelestialMath;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.random.Random;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * IMPLEMENTED - pairs with AuroraSkyModule as the other "custom sky"
 * piece. Spawns an occasional streak that sweeps across the dome and
 * fades out, with a short tapering tail. Ticking (spawn logic) and
 * rendering (drawing) are deliberately split: ticks are cheap and run
 * once per game tick, rendering runs once per frame.
 */
public class ShootingStarsModule extends Module {

    private record Star(double startYaw, double startPitch, double endYaw, double endPitch, long startedAtMs, long lifetimeMs) {
        float progress(long now) {
            return Math.min(1f, (now - startedAtMs) / (float) lifetimeMs);
        }
    }

    private static final double DOME_RADIUS = 100.0;
    private static final int MAX_CONCURRENT = 2;
    private static final float SPAWN_CHANCE_PER_TICK = 1f / 300f; // roughly every ~15s when conditions allow
    private static final int TAIL_SAMPLES = 10;
    private static final int STAR_COLOR = 0xFFFFFF;

    private final List<Star> activeStars = new ArrayList<>();
    private final Random random = Random.create();

    public ShootingStarsModule() {
        super("shooting_stars", "Shooting Stars", ModuleCategory.WORLD,
                "Occasional shooting star streaks across the night sky.", true);
        ClientTickEvents.END_WORLD_TICK.register(this::onWorldTick);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onRenderSky);
    }

    private void onWorldTick(ClientWorld world) {
        if (!isEnabled()) return;
        if (!world.getRegistryKey().equals(net.minecraft.world.World.OVERWORLD)) return;
        long time = Math.floorMod(world.getTimeOfDay(), 24000L);
        if (time < 12000L || time >= 23000L) return;
        if (activeStars.size() >= MAX_CONCURRENT) return;
        if (random.nextFloat() > SPAWN_CHANCE_PER_TICK * VisualConfig.get().particleDensity) return;

        spawnStar();
    }

    private void spawnStar() {
        double startYaw = random.nextDouble() * 360.0;
        double startPitch = 40.0 + random.nextDouble() * 40.0; // upper half of the sky
        double sweepYaw = 25.0 + random.nextDouble() * 35.0;
        double sweepPitch = -(10.0 + random.nextDouble() * 20.0); // streaks arc downward

        activeStars.add(new Star(
                startYaw, startPitch,
                startYaw + sweepYaw, startPitch + sweepPitch,
                System.currentTimeMillis(),
                Math.max(180L, (long) ((700 + random.nextInt(600)) / VisualConfig.get().animationSpeed))));
    }

    private void onRenderSky(WorldRenderContext context) {
        if (!isEnabled() || activeStars.isEmpty()) return;

        long now = System.currentTimeMillis();
        Iterator<Star> it = activeStars.iterator();
        while (it.hasNext()) {
            Star star = it.next();
            float progress = star.progress(now);
            if (progress >= 1f) {
                it.remove();
                continue;
            }
            context.commandQueue().submitCustom(context.matrices(), RenderLayers.debugQuads(),
                    (matrix, vertices) -> drawStar(vertices, matrix, star, progress));
        }
    }

    private void drawStar(VertexConsumer vertices, MatrixStack.Entry matrix, Star star, float headProgress) {
        // overall fade-in / fade-out envelope so it doesn't pop in/out abruptly
        float envelope = CelestialMath.smoothPulse(headProgress);

        for (int i = 0; i < TAIL_SAMPLES; i++) {
            // walk backward from the head along the tail, each step a bit further behind and dimmer
            float sampleT = headProgress - (i / (float) TAIL_SAMPLES) * 0.12f;
            if (sampleT < 0f) sampleT = 0f;
            float nextT = headProgress - ((i + 1) / (float) TAIL_SAMPLES) * 0.12f;
            if (nextT < 0f) nextT = 0f;

            // thin perpendicular offset so the tail has visible width instead of being a zero-width line
            Vector3f dir = CelestialMath.toCartesian(star.endYaw(), star.endPitch(), 1)
                    .sub(CelestialMath.toCartesian(star.startYaw(), star.startPitch(), 1));
            Vector3f perp = new Vector3f(-dir.z, 0, dir.x);
            if (perp.lengthSquared() > 0.0001f) perp.normalize();
            Vector3f head = starPosition(star, sampleT);
            Vector3f tail = starPosition(star, nextT);
            float headWidth = 0.35f * (1f - i / (float) TAIL_SAMPLES);
            float tailWidth = 0.35f * (1f - (i + 1) / (float) TAIL_SAMPLES);
            float headAlpha = envelope * (1f - i / (float) TAIL_SAMPLES);
            float tailAlpha = envelope * (1f - (i + 1) / (float) TAIL_SAMPLES);

            emit(vertices, matrix, new Vector3f(head).add(new Vector3f(perp).mul(headWidth)), headAlpha);
            emit(vertices, matrix, new Vector3f(head).sub(new Vector3f(perp).mul(headWidth)), headAlpha);
            emit(vertices, matrix, new Vector3f(tail).sub(new Vector3f(perp).mul(tailWidth)), tailAlpha);
            emit(vertices, matrix, new Vector3f(tail).add(new Vector3f(perp).mul(tailWidth)), tailAlpha);
        }
    }

    private Vector3f starPosition(Star star, float progress) {
        double yaw = lerp(star.startYaw(), star.endYaw(), progress);
        double pitch = lerp(star.startPitch(), star.endPitch(), progress);
        return CelestialMath.toCartesian(yaw, pitch, DOME_RADIUS);
    }

    private void emit(VertexConsumer vertices, MatrixStack.Entry matrix, Vector3f position, float alpha) {
        int color = VisualConfig.get().primaryColor();
        float red = ((color >> 16) & 0xFF) / 255f;
        float green = ((color >> 8) & 0xFF) / 255f;
        float blue = (color & 0xFF) / 255f;
        vertices.vertex(matrix, position).color(red, green, blue, Math.min(1f, alpha * VisualConfig.get().intensity));
    }

    private double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    @Override
    protected void onDisable(MinecraftClient client) {
        activeStars.clear();
    }
}
