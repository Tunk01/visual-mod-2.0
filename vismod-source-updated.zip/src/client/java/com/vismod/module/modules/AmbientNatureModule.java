package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.random.Random;

/** Client-only decorative particles. It never reads hidden gameplay information. */
public class AmbientNatureModule extends Module {
    private final Random random = Random.create();

    public AmbientNatureModule() {
        super("ambient_particles", "Ambient Nature", ModuleCategory.WORLD,
                "Decorative fireflies, dust, sparks, and mist around the local camera.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null || client.player == null || client.isPaused()) return;
        if (random.nextFloat() > Math.min(1f, 0.24f * VisualConfig.get().particleDensity)) return;
        double x = client.player.getX() + (random.nextDouble() - 0.5) * 16.0;
        double y = client.player.getY() + 0.5 + random.nextDouble() * 4.0;
        double z = client.player.getZ() + (random.nextDouble() - 0.5) * 16.0;
        if (world.isNight()) {
            world.addParticleClient(ParticleTypes.END_ROD, x, y, z, 0.0, 0.005, 0.0);
        } else if (world.isRaining()) {
            world.addParticleClient(ParticleTypes.SPLASH, x, y, z, 0.0, 0.02, 0.0);
        } else {
            world.addParticleClient(ParticleTypes.WHITE_ASH, x, y, z, 0.0, 0.008, 0.0);
        }
    }
}