package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

/**
 * IMPLEMENTED - the "Motion" category template. Any module that reacts to
 * velocity (Swing Afterimage, Player Afterimages, Jump Circles) follows
 * this same shape: read entity velocity each tick, compare to a threshold,
 * spawn something at the entity's previous/current position.
 */
public class PlayerTrailsModule extends Module {

    private static final double SPEED_THRESHOLD = 0.18; // sprint-ish horizontal speed

    public PlayerTrailsModule() {
        super("player_trails", "Player Trails", ModuleCategory.MOTION,
                "Leaves a light particle trail behind players moving quickly.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;

        for (PlayerEntity player : world.getPlayers()) {
            double dx = player.getVelocity().x;
            double dz = player.getVelocity().z;
            double horizontalSpeed = Math.sqrt(dx * dx + dz * dz);
            if (horizontalSpeed < SPEED_THRESHOLD) continue;
            if (player.isSneaking()) continue;

                    int count = Math.max(1, Math.round(VisualConfig.get().particleDensity));
                    for (int i = 0; i < count; i++) {
                        world.addParticleClient(ParticleTypes.CLOUD,
                                player.getX(), player.getY() + 0.1, player.getZ(), 0.0, 0.0, 0.0);
                    }
        }
    }
}
