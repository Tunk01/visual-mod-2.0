package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** IMPLEMENTED - draws a small particle ring under a player's feet the tick they leave the ground. */
public class JumpCirclesModule extends Module {

    private static final int RING_POINTS = 12;
    private static final double RADIUS = 0.35;

    // tracks who was on the ground last tick so we only fire once per jump
    private final Set<Integer> wasOnGround = new HashSet<>();

    public JumpCirclesModule() {
        super("jump_circles", "Jump Circles", ModuleCategory.MOTION,
                "A ring of particles at your feet the moment you leave the ground.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;

        for (PlayerEntity player : world.getPlayers()) {
            int id = player.getId();
            boolean onGround = player.isOnGround();

            if (!onGround && wasOnGround.contains(id)) {
                spawnRing(world, player);
            }

            if (onGround) {
                wasOnGround.add(id);
            } else {
                wasOnGround.remove(id);
            }
        }
    }

    private void spawnRing(ClientWorld world, PlayerEntity player) {
        int points = Math.max(4, Math.round(RING_POINTS * VisualConfig.get().particleDensity));
        for (int i = 0; i < points; i++) {
            double angle = (2 * Math.PI / points) * i;
            double x = player.getX() + Math.cos(angle) * RADIUS;
            double z = player.getZ() + Math.sin(angle) * RADIUS;
                        world.addParticleClient(ParticleTypes.POOF,
                            x, player.getY() + 0.05, z, 0.0, 0.0, 0.0);
        }
    }

    @Override
    protected void onDisable(MinecraftClient client) {
        wasOnGround.clear();
    }
}
