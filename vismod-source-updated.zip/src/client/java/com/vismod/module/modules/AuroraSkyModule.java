package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import com.vismod.render.CelestialMath;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector3f;

/**
 * IMPLEMENTED - "Skyboxes" slot repurposed as a proper aurora effect.
 *
 * Draws 3 drifting ribbon bands high overhead, each a soft vertical-fade
 * triangle strip positioned on the sky dome (same trick vanilla uses for
 * stars - geometry is placed relative to the camera, not the world, so it
 * never gets closer/farther as you move). Colors cycle slowly between
 * aurora green, cyan and violet; the ribbons wave using layered sine
 * functions so they never repeat in an obviously loopy way.
 *
 * Rendering uses the ordered command queue introduced by Minecraft 1.21.11.
 */
public class AuroraSkyModule extends Module {

    private static final int BANDS = 3;
    private static final int SEGMENTS = 48;
    private static final double DOME_RADIUS = 100.0;
    private static final double ARC_DEGREES = 160.0; // how much of the horizon each band sweeps
    private static final double RIBBON_HALF_WIDTH_DEG = 9.0;

    private static final int COLOR_GREEN = 0x39FF8C;
    private static final int COLOR_CYAN = 0x4FE0FF;
    private static final int COLOR_VIOLET = 0xA06BFF;

    public AuroraSkyModule() {
        super("skyboxes", "Skyboxes", ModuleCategory.WORLD,
                "Animated aurora curtains across the night sky.", true);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onRenderSky);
    }

    private void onRenderSky(WorldRenderContext context) {
        if (!isEnabled()) return;

        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null || !world.getRegistryKey().equals(net.minecraft.world.World.OVERWORLD)) return;
        if (!isNightEnough(world)) return;

        VisualConfig style = VisualConfig.get();
        float timeSeconds = (System.currentTimeMillis() % 1_000_000L) / 1000f * style.animationSpeed;
        for (int band = 0; band < BANDS; band++) {
            int bandIndex = band;
            context.commandQueue().submitCustom(context.matrices(), RenderLayers.debugQuads(),
                    (matrix, vertices) -> drawBand(vertices, matrix, bandIndex, timeSeconds));
        }
    }

    /** Fades in starting a bit before full dark, matches vanilla star visibility roughly. */
    private boolean isNightEnough(ClientWorld world) {
        long time = Math.floorMod(world.getTimeOfDay(), 24000L);
        return time >= 12000L && time < 23000L;
    }

    private void drawBand(VertexConsumer vertices, MatrixStack.Entry matrix, int bandIndex, float time) {
        double baseYaw = -ARC_DEGREES / 2.0 + bandIndex * 35.0; // stagger each band's start
        double basePitch = 35.0 + bandIndex * 14.0;             // stack bands at different heights
        double phase = bandIndex * 2.1;

        for (int i = 0; i < SEGMENTS; i++) {
            double start = i / (double) SEGMENTS;
            double end = (i + 1) / (double) SEGMENTS;
            emitRibbonEdge(vertices, matrix, bandIndex, time, baseYaw, basePitch, phase, start, true);
            emitRibbonEdge(vertices, matrix, bandIndex, time, baseYaw, basePitch, phase, start, false);
            emitRibbonEdge(vertices, matrix, bandIndex, time, baseYaw, basePitch, phase, end, false);
            emitRibbonEdge(vertices, matrix, bandIndex, time, baseYaw, basePitch, phase, end, true);
        }
    }

    private void emitRibbonEdge(VertexConsumer vertices, MatrixStack.Entry matrix, int bandIndex, float time,
                                double baseYaw, double basePitch, double phase, double t, boolean top) {
        double yaw = baseYaw + t * ARC_DEGREES;
        double wave = Math.sin(t * 6.0 + time * 0.35 + phase) * 6.0
                + Math.sin(t * 2.3 - time * 0.2 + phase) * 4.0;
        double pitch = basePitch + wave + (top ? RIBBON_HALF_WIDTH_DEG : -RIBBON_HALF_WIDTH_DEG);
        float edgeFade = (float) Math.sin(Math.PI * t);
        VisualConfig style = VisualConfig.get();
        int color = CelestialMath.lerpRgb(style.primaryColor() & 0xFFFFFF,
                style.accentColor() & 0xFFFFFF,
                (float) ((Math.sin(t * 3.0 + time * 0.5 + phase) + 1.0) / 2.0));
        float red = ((color >> 16) & 0xFF) / 255f;
        float green = ((color >> 8) & 0xFF) / 255f;
        float blue = (color & 0xFF) / 255f;
        float alpha = top ? 0f : Math.min(0.85f, 0.45f * edgeFade * VisualConfig.get().intensity);
        Vector3f position = CelestialMath.toCartesian(yaw, pitch, DOME_RADIUS);
        vertices.vertex(matrix, position).color(red, green, blue, alpha);
    }
}
