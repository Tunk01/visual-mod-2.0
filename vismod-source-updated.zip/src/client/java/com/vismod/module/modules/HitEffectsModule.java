package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * IMPLEMENTED - "Damage Feedback" / "Hit Effects" template.
 * We don't have a clean client-side "entity was damaged" event without a
 * mixin, so instead we track each living entity's health per tick and
 * diff it - a drop means it took damage. Cheap, reliable, no mixin.
 */
public class HitEffectsModule extends Module {

    private final Map<Integer, Float> lastHealth = new HashMap<>();

    public HitEffectsModule() {
        super("hit_effects", "Hit Effects", ModuleCategory.ENTITIES,
                "Particle burst whenever an entity near you takes damage.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;

        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;

            float current = living.getHealth();
            Float previous = lastHealth.put(entity.getId(), current);
            if (previous != null && current < previous) {
                burst(world, living);
            }
        }
    }

    private void burst(ClientWorld world, LivingEntity entity) {
        int count = Math.max(2, Math.round(6f * VisualConfig.get().intensity * VisualConfig.get().particleDensity));
        for (int i = 0; i < count; i++) {
                    world.addParticleClient(ParticleTypes.CRIT,
                        entity.getX(), entity.getY() + entity.getHeight() * 0.5, entity.getZ(),
                    (world.random.nextDouble() - 0.5) * 0.3,
                    world.random.nextDouble() * 0.2,
                        (world.random.nextDouble() - 0.5) * 0.3);
        }
    }

    @Override
    protected void onDisable(MinecraftClient client) {
        lastHealth.clear();
    }
}
