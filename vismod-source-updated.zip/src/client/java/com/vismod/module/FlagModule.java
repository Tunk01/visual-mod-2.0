package com.vismod.module;

/**
 * For modules with no Java-side tick/render logic of their own - the
 * corresponding mixin reads ModuleManager.isEnabled(id) directly. Used by
 * Nametags and Weather, which only ever cancel a vanilla render call.
 */
public final class FlagModule extends Module {
    public FlagModule(String id, String displayName, ModuleCategory category, String description, boolean enabledByDefault) {
        super(id, displayName, category, description, enabledByDefault);
    }
}
