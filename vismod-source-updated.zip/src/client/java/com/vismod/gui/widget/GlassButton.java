package com.vismod.gui.widget;

import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;

/** A ButtonWidget that paints itself as a frosted-glass pill instead of the vanilla stone texture. */
public class GlassButton extends ClickableWidget {

    private final Consumer<GlassButton> onPress;
    private float hoverAmount;

    protected GlassButton(int x, int y, int width, int height, net.minecraft.text.Text message,
                          Consumer<GlassButton> onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    public static GlassButton of(int x, int y, int width, int height, net.minecraft.text.Text message,
                                 Consumer<GlassButton> onPress) {
        return new GlassButton(x, y, width, height, message, onPress);
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        boolean hovered = isHovered();
        float target = hovered ? 1.0f : 0.0f;
        hoverAmount += (target - hoverAmount) * Math.min(1.0f, delta * 0.22f + 0.08f);
        GlassRenderer.panel(context, getX(), getY(), getWidth(), getHeight(),
                hovered ? 0x4D000000 : 0x33000000,
                hovered ? 0x60FFFFFF : 0x30FFFFFF);

        int accent = (int) (hoverAmount * 0x90);
        int accentColor = com.vismod.config.VisualConfig.get().animatedPrimaryColor();
        if (accent > 0) {
            context.fill(getX() + 2, getY() + getHeight() - 2,
                    getX() + getWidth() - 2, getY() + getHeight() - 1,
                    (accent << 24) | (accentColor & 0x00FFFFFF));
            int sweep = (int) ((System.currentTimeMillis() / 4L) % Math.max(1, getWidth()));
            context.fill(getX() + sweep, getY() + 1,
                    Math.min(getX() + sweep + 2, getX() + getWidth()), getY() + 2,
                    (accent << 24) | 0xFFFFFF);
        }

        int textColor = active ? 0xFFFFFFFF : 0xFF909090;
        context.drawCenteredTextWithShadow(
                net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                getMessage(),
                getX() + getWidth() / 2,
                getY() + (getHeight() - 8) / 2,
                textColor);
    }

    @Override
    public void onClick(Click click, boolean doubleClick) {
        onPress.accept(this);
    }

    @Override
    protected void appendClickableNarrations(
            net.minecraft.client.gui.screen.narration.NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, getMessage().getString());
    }
}
