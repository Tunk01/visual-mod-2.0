package com.vismod.gui.widget;

import com.vismod.module.Module;
import com.vismod.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/**
 * One row: [star] Module Name ............ (gear, if hasExtraSettings) [toggle pill]
 * Matches the layout in the reference screenshots exactly.
 */
public class ModuleRow extends ClickableWidget {

    private static final int STAR_SIZE = 10;
    private static final int TOGGLE_WIDTH = 28;
    private static final int TOGGLE_HEIGHT = 14;

    private final Module module;

    public ModuleRow(Module module, int x, int y, int width, int height) {
        super(x, y, width, height, Text.literal(module.displayName()));
        this.module = module;
    }

    public Module module() {
        return module;
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean rowHovered = mouseX >= getX() && mouseX <= getX() + getWidth()
                && mouseY >= getY() && mouseY <= getY() + getHeight();

        if (rowHovered) {
            context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), 0x14FFFFFF);
        }

        // star
        int starX = getX() + 4;
        int starY = getY() + (getHeight() - STAR_SIZE) / 2;
        boolean starHovered = isOver(mouseX, mouseY, starX, starY, STAR_SIZE, STAR_SIZE);
        int starColor = module.isStarred() ? 0xFFE3B341 : (starHovered ? 0xFFFFFFFF : 0xFF5A5A5A);
        context.drawTextWithShadow(client.textRenderer, module.isStarred() ? "\u2605" : "\u2606", starX, starY, starColor);

        // name
        int textX = starX + STAR_SIZE + 6;
        int textY = getY() + (getHeight() - 8) / 2;
        context.drawTextWithShadow(client.textRenderer, module.displayName(), textX, textY, 0xFFE4E4E8);

        // toggle pill, right-aligned
        int toggleX = getX() + getWidth() - TOGGLE_WIDTH - 4;
        int toggleY = getY() + (getHeight() - TOGGLE_HEIGHT) / 2;
        drawTogglePill(context, toggleX, toggleY, module.isEnabled());
    }

    private void drawTogglePill(DrawContext context, int x, int y, boolean on) {
        int trackColor = on ? 0xFFB479F0 : 0xFF3A3A42; // purple when on, matches screenshots
        context.fill(x, y, x + TOGGLE_WIDTH, y + TOGGLE_HEIGHT, trackColor);
        // rounded knob approximation
        int knobSize = TOGGLE_HEIGHT - 4;
        int knobX = on ? x + TOGGLE_WIDTH - knobSize - 2 : x + 2;
        context.fill(knobX, y + 2, knobX + knobSize, y + 2 + knobSize, 0xFFFFFFFF);
    }

    @Override
    public void onClick(Click click, boolean doubleClick) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int starX = getX() + 4;
        int starY = getY() + (getHeight() - STAR_SIZE) / 2;
        if (isOver((int) mouseX, (int) mouseY, starX, starY, STAR_SIZE, STAR_SIZE)) {
            ModuleManager.setStarred(module, !module.isStarred());
            return;
        }

        int toggleX = getX() + getWidth() - TOGGLE_WIDTH - 4;
        int toggleY = getY() + (getHeight() - TOGGLE_HEIGHT) / 2;
        if (isOver((int) mouseX, (int) mouseY, toggleX, toggleY, TOGGLE_WIDTH, TOGGLE_HEIGHT)) {
            ModuleManager.setEnabled(module, !module.isEnabled());
            return;
        }

        if (module.hasExtraSettings()) {
            module.openSettings(MinecraftClient.getInstance());
        }
    }

    private boolean isOver(int mouseX, int mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    @Override
    protected void appendClickableNarrations(net.minecraft.client.gui.screen.narration.NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, module.displayName());
    }
}
