package com.vismod.gui;

import com.vismod.config.BackgroundImageManager;
import com.vismod.gui.widget.GlassButton;
import com.vismod.render.GlassRenderer;
import com.vismod.render.VisModBackdrop;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.text.Text;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Replaces vanilla's TitleScreen (swapped in from VisModClient via
 * ScreenEvents.BEFORE_INIT - see that class for why no mixin is needed).
 * Layout matches the reference screenshot: big clock + date + greeting up
 * top, Singleplayer/Multiplayer as the primary glass buttons, a row of
 * secondary glass buttons (Theme/Studio/Mods/Realms/Options/Quit) along
 * the bottom.
 */
public class CustomTitleScreen extends Screen {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public CustomTitleScreen() {
        super(Text.literal("VisMod Title Screen"));
    }

    @Override
    protected void init() {
        int centerX = width / 2;

        // primary buttons
        int primaryWidth = 200;
        int primaryY = height / 2 + 10;
        addDrawableChild(GlassButton.of(centerX - primaryWidth - 5, primaryY, primaryWidth, 26,
                Text.literal("Singleplayer"),
                btn -> client.setScreen(new SelectWorldScreen(this))));
        addDrawableChild(GlassButton.of(centerX + 5, primaryY, primaryWidth, 26,
                Text.literal("Multiplayer"),
                btn -> client.setScreen(new MultiplayerScreen(this))));

        // secondary row along the bottom, matches "Theme Studio Mods Realms Options Quit"
        String[] labels = {"Theme", "Studio", "Mods", "Realms", "Options", "Quit"};
        int secondaryWidth = 72;
        int gap = 6;
        int totalWidth = labels.length * secondaryWidth + (labels.length - 1) * gap;
        int startX = centerX - totalWidth / 2;
        int secondaryY = height - 34;

        for (int i = 0; i < labels.length; i++) {
            String label = labels[i];
            int x = startX + i * (secondaryWidth + gap);
            addDrawableChild(GlassButton.of(x, secondaryY, secondaryWidth, 20, Text.literal(label), btn -> onSecondary(label)));
        }
    }

    private void onSecondary(String label) {
        switch (label) {
            case "Theme" -> BackgroundImageManager.promptAndLoad(null);
            case "Options" -> client.setScreen(new OptionsScreen(this, client.options));
            case "Quit" -> client.scheduleStop();
            // "Studio", "Mods", "Realms" - wire these to your own screens as you build them out
            default -> {}
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackgroundLayer(context, delta);
        super.render(context, mouseX, mouseY, delta);
        renderClockAndGreeting(context);
        renderBranding(context);
    }

    private void renderBranding(DrawContext context) {
        int centerX = width / 2;
        context.drawCenteredTextWithShadow(textRenderer, "V I S M O D", centerX, 18, 0xFF8FE8FF);
        context.drawCenteredTextWithShadow(textRenderer,
                "CLIENT-SIDE VISUALS  •  COSMETIC ONLY", centerX, height - 52, 0x90C9EFFF);
    }

    private void renderBackgroundLayer(DrawContext context, float delta) {
        if (BackgroundImageManager.hasCustomBackground()) {
            context.drawTexture(
                    RenderPipelines.GUI_TEXTURED,
                    BackgroundImageManager.textureId(),
                    0, 0, 0.0f, 0.0f, width, height, width, height);
            // darken slightly so white text/buttons stay legible over any photo
            context.fill(0, 0, width, height, 0x60000000);
        } else {
            VisModBackdrop.draw(context, width, height, System.currentTimeMillis());
        }
    }

    private void renderClockAndGreeting(DrawContext context) {
        LocalDateTime now = LocalDateTime.now();
        String time = now.format(TIME_FORMAT);
        String date = now.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault())
                + ", " + now.getDayOfMonth() + " "
                + now.getMonth().getDisplayName(TextStyle.FULL, Locale.getDefault());

        int centerX = width / 2;
        int y = 40;
        GlassRenderer.panel(context, centerX - totalPanelWidth() / 2 - 12, y - 10, totalPanelWidth() + 24, 100,
                0x20000000, 0x20FFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, date, centerX, y, 0xFFE4E4E8);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(centerX - textRenderer.getWidth(time), y + 14);
        context.getMatrices().scale(2f, 2f);
        context.drawText(textRenderer, time, 0, 0, 0xFFFFFFFF, true);
        context.getMatrices().popMatrix();

        String playerName = client.getSession() != null ? client.getSession().getUsername() : "Player";
        String greeting = greetingForHour(now.getHour()) + ", " + playerName;
        context.drawCenteredTextWithShadow(textRenderer, greeting, centerX, y + 60, 0xFFC9C9D4);
    }
    private int totalPanelWidth() {
        return 220;
    }

    private String greetingForHour(int hour) {
        if (hour < 12) return "Good morning";
        if (hour < 18) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
