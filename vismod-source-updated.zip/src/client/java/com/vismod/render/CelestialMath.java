package com.vismod.render;

import org.joml.Vector3f;

/**
 * Helpers shared by AuroraSkyModule and ShootingStarsModule: both place
 * geometry on an imaginary dome around the camera (same trick vanilla
 * uses for stars/sun/moon), described in yaw/pitch degrees, then convert
 * to a 3D point at a fixed radius.
 *
 * yaw: 0 = +Z, increases clockwise looking down from above (matches
 *      Minecraft's world yaw convention closely enough for a sky effect -
 *      it doesn't need to be exact, just consistent).
 * pitch: 0 = horizon, 90 = straight up.
 */
public final class CelestialMath {

    private CelestialMath() {}

    public static Vector3f toCartesian(double yawDeg, double pitchDeg, double radius) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        float x = (float) (radius * Math.cos(pitch) * Math.sin(yaw));
        float y = (float) (radius * Math.sin(pitch));
        float z = (float) (radius * Math.cos(pitch) * Math.cos(yaw));
        return new Vector3f(x, y, z);
    }

    /** Linear-interpolates two 0-255 RGB colors packed as ints (0xRRGGBB). */
    public static int lerpRgb(int colorA, int colorB, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (colorA >> 16) & 0xFF, ag = (colorA >> 8) & 0xFF, ab = colorA & 0xFF;
        int br = (colorB >> 16) & 0xFF, bg = (colorB >> 8) & 0xFF, bb = colorB & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int b = (int) (ab + (bb - ab) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static float smoothPulse(float t) {
        // ease in/out, used to fade things at the start/end of their lifetime
        return (float) (Math.sin(Math.PI * Math.max(0, Math.min(1, t))));
    }
}
