package com.vismod.render;

import net.minecraft.client.gui.DrawContext;
import com.vismod.config.VisualConfig;

/** Small, deterministic UI-only animation helpers. Nothing here reads world/entity data. */
public final class VisModBackdrop {
    private VisModBackdrop() {}

    public static void draw(DrawContext context, int width, int height, long nowMs) {
        float t = (nowMs % 16000L) / 16000.0f;
        int drift = (int) (Math.sin(t * Math.PI * 2.0) * 18.0);
        int primary = VisualConfig.get().animatedPrimaryColor();
        context.fillGradient(0, 0, width, height, 0xFF111222, 0xFF05050A);
        context.fillGradient(0, 0, width, height / 2, (0x38 << 24) | (primary & 0x00FFFFFF), 0x001E8BFF);
        orb(context, width / 5 + drift, height / 4, 150, 0x182B7BFF);
        orb(context, width * 4 / 5 - drift, height * 3 / 5, 190, 0x1618D9B5);
        orb(context, width / 2, height + 50 - drift, 210, 0x121D4ED8);
        for (int i = 0; i < 26; i++) {
            double phase = i * 2.417;
            int x = (int) ((i * 83 + nowMs / (18 + i % 5) + Math.sin(phase) * 40) % Math.max(1, width));
            int y = (int) ((i * 47 + nowMs / (26 + i % 7) + Math.cos(phase) * 24) % Math.max(1, height));
            int alpha = 0x18 + (i % 4) * 0x08;
            context.fill(x, y, x + 2, y + 2, (alpha << 24) | 0xB8E8FF);
        }
    }

    private static void orb(DrawContext context, int cx, int cy, int size, int color) {
        int half = size / 2;
        context.fill(cx - half, cy - half, cx + half, cy + half, color);
        context.fill(cx - half / 2, cy - half / 2, cx + half / 2, cy + half / 2, color | 0x08000000);
    }
}