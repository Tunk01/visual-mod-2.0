package com.vismod.render;

import net.minecraft.client.gui.DrawContext;
import com.vismod.config.VisualConfig;

/**
 * Draws the "frosted glass" panel/button look from the reference
 * screenshot: a blurred backdrop, a translucent fill, a soft top
 * highlight, and a thin light border.
 *
 * Real gaussian blur of the backdrop behind a GUI element needs a
 * post-process shader pass over the whole framebuffer - Minecraft
 * ships one for the pause menu (GameRenderer#applyBlur), which we
 * reuse in {@link #blurBackdrop}. If your mappings don't have that
 * exact method, either delete the call (panels still look fine, just
 * without blur) or wire up your own .json post-effect shader under
 * assets/vismod/shaders/post - that's the "proper" way to blur only
 * once per frame instead of per panel.
 */
public final class GlassRenderer {

    private GlassRenderer() {}

    /** Call once per frame, before drawing any glass panels, to blur whatever is already on screen. */
    public static void blurBackdrop(DrawContext context) {
        context.applyBlur();
    }

    /** A translucent rounded-ish panel. radius is approximated with corner notches since DrawContext has no native round-rect. */
    public static void panel(DrawContext context, int x, int y, int width, int height, int fillArgb, int borderArgb) {
        int x2 = x + width;
        int y2 = y + height;

        // base fill
        int baseAlpha = (fillArgb >>> 24) & 0xFF;
        int scaledAlpha = (int) (baseAlpha * VisualConfig.get().menuOpacity);
        int fill = (fillArgb & 0x00FFFFFF) | ((scaledAlpha & 0xFF) << 24);
        context.fill(x, y, x2, y2, fill);

        // soft top highlight (glass catching light from above)
        context.fillGradient(x, y, x2, y + Math.max(2, height / 4), 0x30FFFFFF, 0x00FFFFFF);

        // thin border
        context.fill(x, y, x2, y + 1, borderArgb);          // top
        context.fill(x, y2 - 1, x2, y2, 0x20000000);         // bottom (soft shadow edge)
        context.fill(x, y, x + 1, y2, borderArgb);           // left
        context.fill(x2 - 1, y, x2, y2, borderArgb);         // right

        // corner notches to fake rounding at a small scale
        context.fill(x, y, x + 2, y + 1, 0x00000000);
        context.fill(x2 - 2, y, x2, y + 1, 0x00000000);
    }

    /** Default glass button colors matching the reference screenshot (dark translucent + faint white border). */
    public static void button(DrawContext context, int x, int y, int width, int height, boolean hovered) {
        panel(context, x, y, width, height, hovered ? 0x4D000000 : 0x33000000, hovered ? 0x60FFFFFF : 0x30FFFFFF);
    }
}
