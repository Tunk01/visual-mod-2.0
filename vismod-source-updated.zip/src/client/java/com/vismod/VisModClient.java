package com.vismod;

import com.vismod.gui.CustomLoadingScreen;
import com.vismod.gui.CustomTitleScreen;
import com.vismod.gui.VisualsConfigScreen;
import com.vismod.config.VisualConfig;
import com.vismod.module.ModuleManager;
import com.vismod.module.ModuleRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class VisModClient implements ClientModInitializer {

    private static KeyBinding openConfigKey;
    private boolean seenTitleOnce = false;

    @Override
    public void onInitializeClient() {
        VisualConfig.load();
        ModuleRegistry.registerAll();
        ModuleManager.loadAndApply();

        // drive every module's onClientTick
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::onClientTick);

        // swap vanilla's TitleScreen for ours the moment it tries to open, without a mixin.
        // The "exact class match" check stops this from also catching subclasses (like our own
        // screens, if Minecraft ever treated one as a TitleScreen) and causing a loop. Only the
        // very first time shows the loading splash; after that (e.g. after disconnecting from a
        // server) we jump straight to the title screen.
        ScreenEvents.BEFORE_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen.getClass() == TitleScreen.class) {
                if (!seenTitleOnce) {
                    seenTitleOnce = true;
                    client.execute(() -> client.setScreen(
                            new CustomLoadingScreen(() -> client.setScreen(new CustomTitleScreen()))));
                } else {
                    client.execute(() -> client.setScreen(new CustomTitleScreen()));
                }
            }
        });

        // keybind to open the config screen from in-game, default RIGHT SHIFT
        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vismod.open_config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("vismod", "category"))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new VisualsConfigScreen(null));
                }
            }
        });
    }
}
