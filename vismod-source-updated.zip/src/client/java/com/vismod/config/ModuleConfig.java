package com.vismod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Flat persistence layer: config/vismod/modules.json
 * { "moduleId": { "enabled": true, "starred": false }, ... }
 *
 * Deliberately dumb and defensive - a missing/corrupt file just means
 * every module falls back to its coded default rather than crashing
 * the client.
 */
public final class ModuleConfig {

    public static final class Entry {
        public boolean enabled;
        public boolean starred;

        public Entry() {}

        public Entry(boolean enabled, boolean starred) {
            this.enabled = enabled;
            this.starred = starred;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<HashMap<String, Entry>>() {}.getType();
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("vismod");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve("modules.json");

    private final Map<String, Entry> entries;

    private ModuleConfig(Map<String, Entry> entries) {
        this.entries = entries;
    }

    public static ModuleConfig load() {
        try {
            if (Files.exists(CONFIG_FILE)) {
                try (Reader reader = Files.newBufferedReader(CONFIG_FILE, StandardCharsets.UTF_8)) {
                    Map<String, Entry> parsed = GSON.fromJson(reader, MAP_TYPE);
                    if (parsed != null) {
                        return new ModuleConfig(parsed);
                    }
                }
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            System.err.println("[VisMod] Failed to read modules.json, starting fresh: " + e);
        }
        return new ModuleConfig(new HashMap<>());
    }

    public Entry get(String moduleId) {
        return entries.get(moduleId);
    }

    public void put(String moduleId, boolean enabled, boolean starred) {
        entries.put(moduleId, new Entry(enabled, starred));
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_DIR);
            try (Writer writer = Files.newBufferedWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(entries, MAP_TYPE, writer);
            }
        } catch (IOException e) {
            System.err.println("[VisMod] Failed to save modules.json: " + e);
        }
    }
}
