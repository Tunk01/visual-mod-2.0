# VisMod safety scope

VisMod is intended to remain client-side and cosmetic for multiplayer servers.

The project may render ambient particles, sky effects, screen effects, cosmetic animations, menu styling, and other visuals based only on information the client is already allowed to display.

Do not add features that reveal hidden blocks, players, mobs, containers, inventories, health, locations, or server state. Do not add freecam, reach, combat assistance, autoclicking, movement changes, fake entities, or automatic targeting. Any future module that could expose gameplay information should be rejected from the registry.